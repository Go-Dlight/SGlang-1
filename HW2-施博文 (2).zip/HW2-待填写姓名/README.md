# 第二次挑战复现说明

本目录保存 SGLang 前缀缓存对照实验的代码、逐请求记录、汇总结果和报告。实验在同一模型及生成参数下，比较共享前缀与分散前缀两组请求。报告中的主表使用共享组 `run-20260929-182129` 和分散组 `run-20260929-183544`；共享组的另一轮运行保留在结果目录中。

## 环境

| 项目 | 本机实验环境 |
| --- | --- |
| 操作系统 | WSL Ubuntu 22.04.5 LTS |
| GPU | NVIDIA GeForce RTX 5070 Laptop GPU，约 8 GiB 显存 |
| NVIDIA 驱动 | 573.22；`nvidia-smi` 显示 CUDA Version 12.8 |
| Python | 3.10.12 |
| SGLang | 0.5.14 |
| Ray | 2.56.0 |
| PyTorch | 2.11.0+cu129 |
| Transformers | 5.8.1 |
| 模型 | Qwen/Qwen3-0.6B，本机目录 `~/first-challenge/model/Qwen3-0.6B` |

本机复用第一次挑战已建立的 `~/first-challenge/.venv-sglang` 和 `~/first-challenge/.venv-ray`。任务一脚本使用 SGLang 环境中的 Transformers 分词器；Ray 是作业指定的环境版本，但任务一脚本本身未调用 Ray API。

在新 Ubuntu 环境中，先安装与 GPU 驱动兼容的 CUDA 版 PyTorch，再建立 Python 虚拟环境并安装固定版本。下面把虚拟环境放在提交目录外，避免将其误打包：

```bash
python3 -m venv ~/hw2-venv
source ~/hw2-venv/bin/activate
python -m pip install --upgrade pip
python -m pip install "sglang[all]==0.5.14" "transformers==5.8.1" "ray==2.56.0"
```

模型权重不包含在提交包中。请将 Qwen/Qwen3-0.6B 放在上述本机路径，或将 `HW2_MODEL_PATH` 设为实际模型目录。准备负载时只读取本地模型的 tokenizer。

## 启动 SGLang

本机从第一次挑战目录启动服务，使模型 ID 为 `./model/Qwen3-0.6B`：

```bash
cd ~/first-challenge
source .venv-sglang/bin/activate
python -m sglang.launch_server \
  --model-path ./model/Qwen3-0.6B \
  --host 0.0.0.0 --port 30000 \
  --mem-fraction-static 0.65
```

另开一个 Ubuntu 终端，在本提交包根目录运行后续命令。如果服务使用了其他地址或模型 ID，可设置 `HW2_BASE_URL`、`HW2_MODEL_ID`。默认值分别为 `http://127.0.0.1:30000` 和 `./model/Qwen3-0.6B`。

如果在新机器上复现，没有 `~/first-challenge` 目录，可改用：

```bash
export HW2_MODEL_PATH=/absolute/path/to/Qwen3-0.6B
export HW2_MODEL_ID="$HW2_MODEL_PATH"
source ~/hw2-venv/bin/activate
python -m sglang.launch_server --model-path "$HW2_MODEL_PATH" --host 0.0.0.0 --port 30000 --mem-fraction-static 0.65
```

回放实验的另一个终端也需设置相同的 `HW2_MODEL_PATH` 和 `HW2_MODEL_ID`，并激活 `~/hw2-venv`。

## 准备和回放任务一

```bash
cd /path/to/HW2-姓名
source ~/first-challenge/.venv-sglang/bin/activate
python src/target1/prepare_workloads.py
python src/target1/run_benchmark.py check
```

正式实验前，先用一个短请求让服务完成首次运行的初始化。这次请求不计入两组结果：

```bash
python - <<'PY'
import json
import urllib.request

with open("results/target1/shared_prefix/prewarm.json", encoding="utf-8") as f:
    ids = json.load(f)["input_ids"][:16]
body = {
    "input_ids": ids,
    "sampling_params": {"temperature": 0, "max_new_tokens": 1, "ignore_eos": True},
    "stream": False,
}
request = urllib.request.Request(
    "http://127.0.0.1:30000/generate",
    data=json.dumps(body).encode("utf-8"),
    headers={"Content-Type": "application/json"},
    method="POST",
)
with urllib.request.urlopen(request, timeout=600) as response:
    print("服务预热状态:", response.status)
PY
```

依次运行两组实验：

```bash
python src/target1/run_benchmark.py shared_prefix
python src/target1/run_benchmark.py dispersed_prefix
```

每组正式测量前，脚本等待服务空闲，调用 `POST /flush_cache` 并检查返回状态。共享前缀组随后发送一条仅含 2048 个共享 token 的预热请求；分散组保持空缓存。两组各有 32 条正式请求，每条输入 2112 token、输出 16 token，最大并发数为 8。生成设置为 `temperature=0`、`ignore_eos=true`、`sampling_seed=2026`，使用原生 `/generate` 接口的流式响应。脚本按每批 8 条依次发送，下一批在上一批完成后开始。

## 脚本和结果

- `src/target1/prepare_workloads.py`：使用模型 tokenizer 生成固定随机种子的两组 `input_ids`，并写入各组 `requests.jsonl`；共享组另写 `prewarm.json`。
- `src/target1/run_benchmark.py`：检查服务，控制缓存状态与并发，解析流式输出，计算逐请求指标和汇总指标。
- `results/target1/<group>/requests.jsonl`：32 条输入负载。
- `results/target1/<group>/run-*/requests.csv`：逐请求状态、token 数、缓存命中数、TTFT、TPOT 和端到端耗时。
- `results/target1/<group>/run-*/summary.json`：成功率、吞吐量、缓存命中率、实际 Prefill token 数及 p50/p95 汇总。

报告主表与原始结果的对应关系：

| 报告列 | 汇总文件 | 逐请求文件 |
| --- | --- | --- |
| 共享前缀组 | `results/target1/shared_prefix/run-20260929-182129/summary.json` | 同目录 `requests.csv` |
| 分散前缀组 | `results/target1/dispersed_prefix/run-20260929-183544/summary.json` | 同目录 `requests.csv` |

另一次共享组运行保留于 `results/target1/shared_prefix/run-20260929-182306/`，报告主表没有混用该批次的数据。缓存命中率按 `sum(cached_tokens)/sum(prompt_tokens)` 计算；实际 Prefill token 数按 `sum(prompt_tokens-cached_tokens)` 计算。时间字段的单位是秒。
