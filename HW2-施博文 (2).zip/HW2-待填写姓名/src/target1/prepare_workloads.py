import json
import os
import random
from pathlib import Path
from transformers import AutoTokenizer

root = Path(__file__).resolve().parents[2]
model = Path(
    os.environ.get(
        "HW2_MODEL_PATH", str(Path.home() / "first-challenge/model/Qwen3-0.6B")
    )
).expanduser()
out = root / "results/target1"
out_shared = out / "shared_prefix"
out_dispersed = out / "dispersed_prefix"

out_shared.mkdir(parents=True, exist_ok=True)
out_dispersed.mkdir(parents=True, exist_ok=True)

tokenizer = AutoTokenizer.from_pretrained(
    str(model), local_files_only=True, trust_remote_code=True
)
special_ids = set(tokenizer.all_special_ids)
valid_ids = [i for i in range(len(tokenizer)) if i not in special_ids]

rng = random.Random(2026)

# 32 条请求共用相同的 2048-token 开头
common_prefix = rng.choices(valid_ids, k=2048)
suffix_heads = rng.sample(valid_ids, k=32)
shared_requests = []

for i in range(32):
    suffix = [suffix_heads[i]] + rng.choices(valid_ids, k=63)
    shared_requests.append({
        "request_id": f"shared_{i + 1:02d}",
        "input_ids": common_prefix + suffix,
    })

# 预热请求只包含共同的 2048-token 前缀
prewarm_request = {
    "request_id": "shared_prefix_prewarm",
    "input_ids": common_prefix,
}

# 分散组的每条请求从不同 token 开始
dispersed_heads = rng.sample(valid_ids, k=32)
dispersed_requests = []

for i in range(32):
    input_ids = [dispersed_heads[i]] + rng.choices(valid_ids, k=2111)
    dispersed_requests.append({
        "request_id": f"dispersed_{i + 1:02d}",
        "input_ids": input_ids,
    })

def write_jsonl(path, rows):
    with path.open("w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row) + "\n")

write_jsonl(out_shared / "requests.jsonl", shared_requests)
(out_shared / "prewarm.json").write_text(
    json.dumps(prewarm_request), encoding="utf-8"
)
write_jsonl(out_dispersed / "requests.jsonl", dispersed_requests)

assert all(len(r["input_ids"]) == 2112 for r in shared_requests)
assert all(len(r["input_ids"]) == 2112 for r in dispersed_requests)
assert all(r["input_ids"][:2048] == common_prefix for r in shared_requests)
assert len({r["input_ids"][0] for r in dispersed_requests}) == 32

print("共享前缀组：32 条，每条 2112 token，共享开头 2048 token")
print("共享组预热：1 条，输入 2048 token")
print("分散前缀组：32 条，每条 2112 token，开头 token 均不同")
print(f"文件已写入 {out}/")
