#!/usr/bin/env python3
"""Run the Task 1 shared/dispersed prefix benchmark against a local SGLang server."""
import argparse
import concurrent.futures
import csv
import json
import math
import os
import statistics
import time
import urllib.error
import urllib.request
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
RESULTS = ROOT / "results" / "target1"
BASE_URL = os.environ.get("HW2_BASE_URL", "http://127.0.0.1:30000")
EXPECTED_MODEL = os.environ.get("HW2_MODEL_ID", "./model/Qwen3-0.6B")
EXPECTED_SGLANG = "0.5.14"
BATCH_SIZE = 8
MAX_NEW_TOKENS = 16
SEED = 2026


def request_json(path, method="GET", payload=None, timeout=30):
    data = None if payload is None else json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        BASE_URL + path, data=data, method=method,
        headers={"Content-Type": "application/json"} if data is not None else {},
    )
    with urllib.request.urlopen(req, timeout=timeout) as response:
        raw = response.read()
        if not raw:
            parsed = {}
        else:
            try:
                parsed = json.loads(raw)
            except json.JSONDecodeError:
                parsed = {"text": raw.decode("utf-8", errors="replace")}
        return response.status, parsed


def load_json(path):
    with path.open(encoding="utf-8") as f:
        return json.load(f)


def get_server_info():
    status, info = request_json("/server_info")
    if status != 200:
        raise RuntimeError(f"/server_info 返回 HTTP {status}")
    return info


def check():
    info = get_server_info()
    status, models = request_json("/v1/models")
    model_ids = [m.get("id") for m in models.get("data", [])]
    print(f"服务地址：{BASE_URL}")
    print(f"SGLang 版本：{info.get('version', '未提供')}")
    print(f"RadixCache 开关：disable_radix_cache={info.get('disable_radix_cache', '未提供')}")
    print(f"/v1/models：HTTP {status}，模型={model_ids}")
    for group in ("shared_prefix", "dispersed_prefix"):
        path = RESULTS / group / "requests.jsonl"
        with path.open(encoding="utf-8") as f:
            rows = [json.loads(line) for line in f if line.strip()]
        lengths = sorted({len(row["input_ids"]) for row in rows})
        print(f"{group}：{len(rows)} 条请求，输入长度={lengths}")
    prewarm = load_json(RESULTS / "shared_prefix" / "prewarm.json")
    print(f"共享组预热：{len(prewarm['input_ids'])} 个 token（不计入 32 条测量）")
    if info.get("version") != EXPECTED_SGLANG:
        print(f"注意：预期版本 {EXPECTED_SGLANG}，当前版本信息不同。")
    if info.get("disable_radix_cache") is True:
        raise RuntimeError("RadixCache 目前关闭，先不要跑正式测试。")
    if EXPECTED_MODEL not in model_ids:
        print(f"注意：模型列表中没有精确匹配 {EXPECTED_MODEL}，请核对模型 ID。")
    print("检查完成；没有发送正式测量请求。")


def wait_until_idle(timeout=300):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            _, state = request_json("/get_load", timeout=10)
            states = state if isinstance(state, list) else [state]
            running = sum(int(item.get("num_reqs", item.get("running", item.get("num_running_reqs", 0))) or 0) for item in states)
            waiting = sum(int(item.get("num_waiting_reqs", item.get("waiting", 0)) or 0) for item in states)
            if running == 0 and waiting == 0:
                return
        except Exception:
            pass
        time.sleep(2)
    raise TimeoutError("等待服务空闲超过 5 分钟；为避免混入其他请求，停止本次测试。")


def flush_cache():
    wait_until_idle()
    status, result = request_json("/flush_cache", method="POST", payload={}, timeout=30)
    if status != 200 or (isinstance(result, dict) and result.get("success") is False):
        raise RuntimeError(f"清理 RadixCache 失败：HTTP {status} {result}")
    time.sleep(1)
    print("已等待服务空闲并清理缓存。")


def stream_one(item, request_number):
    body = {
        "input_ids": item["input_ids"],
        "sampling_params": {
            "temperature": 0,
            "max_new_tokens": MAX_NEW_TOKENS,
            "ignore_eos": True,
            "sampling_seed": SEED,
        },
        "stream": True,
    }
    encoded = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(
        BASE_URL + "/generate", data=encoded, method="POST",
        headers={"Content-Type": "application/json"},
    )
    started = time.perf_counter()
    first_token_at = None
    output_ids = []
    output_text_parts = []
    meta = {}
    status = None
    error = ""
    try:
        with urllib.request.urlopen(req, timeout=600) as response:
            status = response.status
            for raw_line in response:
                line = raw_line.decode("utf-8", errors="replace").strip()
                if not line.startswith("data:"):
                    continue
                payload = line[5:].strip()
                if payload == "[DONE]":
                    break
                if not payload:
                    continue
                event = json.loads(payload)
                event_meta = event.get("meta_info") or {}
                if event_meta:
                    meta.update(event_meta)
                token_ids = event.get("output_ids")
                if isinstance(token_ids, list):
                    output_ids.extend(token_ids)
                    if token_ids and first_token_at is None:
                        first_token_at = time.perf_counter()
                text_piece = event.get("text")
                if text_piece:
                    output_text_parts.append(text_piece)
                    if first_token_at is None:
                        first_token_at = time.perf_counter()
    except Exception as exc:
        error = f"{type(exc).__name__}: {exc}"
    ended = time.perf_counter()
    output_count = int(meta.get("completion_tokens") or len(output_ids))
    prompt_count = int(meta.get("prompt_tokens") or len(item["input_ids"]))
    cached_count = meta.get("cached_tokens")
    if cached_count is None:
        cached_count = meta.get("cached_token_count")
    ttft = None if first_token_at is None else first_token_at - started
    e2e = ended - started
    tpot = None
    if ttft is not None and output_count > 1:
        tpot = max(0.0, (e2e - ttft) / (output_count - 1))
    return {
        "request": request_number,
        "status": status or "",
        "success": bool(status and 200 <= status < 300 and not error),
        "prompt_tokens": prompt_count,
        "output_tokens": output_count,
        "cached_tokens": "" if cached_count is None else int(cached_count),
        "actual_prefill_tokens": "" if cached_count is None else max(0, prompt_count - int(cached_count)),
        "ttft_s": "" if ttft is None else round(ttft, 6),
        "tpot_s": "" if tpot is None else round(tpot, 6),
        "e2e_s": round(e2e, 6),
        "finish_reason": meta.get("finish_reason", ""),
        "error": error,
    }


def percentile(values, p):
    if not values:
        return None
    ordered = sorted(values)
    return ordered[max(0, math.ceil(p * len(ordered)) - 1)]


def run_group(group):
    if group not in ("shared_prefix", "dispersed_prefix"):
        raise ValueError("group 必须是 shared_prefix 或 dispersed_prefix")
    info = get_server_info()
    print(f"将测试：{group}；服务版本={info.get('version')}；每轮并发最多 {BATCH_SIZE}。")
    flush_cache()

    if group == "shared_prefix":
        warm = load_json(RESULTS / group / "prewarm.json")
        warm_body = {
            "input_ids": warm["input_ids"],
            "sampling_params": {
                "temperature": 0, "max_new_tokens": 1,
                "ignore_eos": True, "sampling_seed": SEED,
            },
            "stream": False,
        }
        _, warm_result = request_json("/generate", method="POST", payload=warm_body, timeout=600)
        if not isinstance(warm_result, dict):
            raise RuntimeError("共享前缀预热没有返回有效 JSON。")
        wait_until_idle()
        print(f"共享前缀已预热：{len(warm['input_ids'])} 个 token；预热请求不计入结果。")
    else:
        print("分散前缀组不预热，保持清理后的空缓存。")

    workload_path = RESULTS / group / "requests.jsonl"
    with workload_path.open(encoding="utf-8") as f:
        requests = [json.loads(line) for line in f if line.strip()]
    if len(requests) != 32:
        raise RuntimeError(f"预期 32 条测量请求，实际读到 {len(requests)} 条。")

    run_dir = RESULTS / group / ("run-" + datetime.now().strftime("%Y%m%d-%H%M%S"))
    run_dir.mkdir(parents=True, exist_ok=False)
    all_rows = []
    run_started = time.perf_counter()
    for start in range(0, len(requests), BATCH_SIZE):
        batch = requests[start:start + BATCH_SIZE]
        print(f"正在测量第 {start + 1}–{start + len(batch)} 条（并发 {len(batch)}）……")
        with concurrent.futures.ThreadPoolExecutor(max_workers=BATCH_SIZE) as pool:
            futures = [
                pool.submit(stream_one, item, start + offset + 1)
                for offset, item in enumerate(batch)
            ]
            all_rows.extend(f.result() for f in futures)
        wait_until_idle()

    run_elapsed = time.perf_counter() - run_started
    csv_path = run_dir / "requests.csv"
    columns = [
        "request", "status", "success", "prompt_tokens", "output_tokens",
        "cached_tokens", "actual_prefill_tokens", "ttft_s", "tpot_s",
        "e2e_s", "finish_reason", "error",
    ]
    with csv_path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=columns)
        writer.writeheader()
        writer.writerows(all_rows)

    successful = [r for r in all_rows if r["success"]]
    def nums(key):
        return [float(r[key]) for r in successful if r[key] != ""]
    total_prompt = sum(int(r["prompt_tokens"]) for r in successful)
    total_output = sum(int(r["output_tokens"]) for r in successful)
    total_cached = sum(int(r["cached_tokens"]) for r in successful if r["cached_tokens"] != "")
    summary = {
        "group": group,
        "sglang_version": info.get("version"),
        "model": EXPECTED_MODEL,
        "requests": len(all_rows),
        "successes": len(successful),
        "success_rate": len(successful) / len(all_rows),
        "concurrency_limit": BATCH_SIZE,
        "sampling": {"temperature": 0, "max_new_tokens": MAX_NEW_TOKENS, "ignore_eos": True, "sampling_seed": SEED},
        "elapsed_s": round(run_elapsed, 6),
        "requests_per_s": round(len(successful) / run_elapsed, 6) if run_elapsed else None,
        "output_tokens_per_s": round(total_output / run_elapsed, 6) if run_elapsed else None,
        "prompt_tokens": total_prompt,
        "output_tokens": total_output,
        "cached_tokens": total_cached,
        "cache_hit_rate": (total_cached / total_prompt) if total_prompt else None,
        "actual_prefill_tokens": sum(int(r["actual_prefill_tokens"]) for r in successful if r["actual_prefill_tokens"] != ""),
        "metrics_s": {
            key: {
                "p50": round(statistics.median(nums(key)), 6) if nums(key) else None,
                "p95": round(percentile(nums(key), 0.95), 6) if nums(key) else None,
            }
            for key in ("ttft_s", "tpot_s", "e2e_s")
        },
        "raw_csv": str(csv_path.relative_to(ROOT)),
        "timestamp": datetime.now().isoformat(timespec="seconds"),
    }
    summary_path = run_dir / "summary.json"
    summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"完成：{len(successful)}/{len(all_rows)} 条成功。")
    print(f"耗时 {run_elapsed:.2f}s；输出吞吐 {summary['output_tokens_per_s']} token/s；缓存命中率 {summary['cache_hit_rate']}.")
    print(f"TTFT p50/p95：{summary['metrics_s']['ttft_s']['p50']} / {summary['metrics_s']['ttft_s']['p95']} 秒")
    print(f"TPOT p50/p95：{summary['metrics_s']['tpot_s']['p50']} / {summary['metrics_s']['tpot_s']['p95']} 秒")
    print(f"E2E p50/p95：{summary['metrics_s']['e2e_s']['p50']} / {summary['metrics_s']['e2e_s']['p95']} 秒")
    print(f"结果文件：{csv_path}")
    print(f"汇总文件：{summary_path}")


def main():
    parser = argparse.ArgumentParser(description="第二次挑战任务一：SGLang 前缀缓存测量")
    parser.add_argument("action", choices=("check", "shared_prefix", "dispersed_prefix"))
    args = parser.parse_args()
    if args.action == "check":
        check()
    else:
        run_group(args.action)


if __name__ == "__main__":
    main()
