#!/usr/bin/env python3
"""Ray Serve ingress that streams requests to one local SGLang backend per replica."""

import asyncio
import os
from typing import AsyncIterator

# Ray reads this setting when its HTTP proxy processes start. Keep the
# session-affinity header explicit before importing Ray.
os.environ.setdefault("RAY_SERVE_SESSION_ID_HEADER_KEY", "x-session-id")

import aiohttp
import ray
from fastapi import FastAPI, Request
from fastapi.responses import StreamingResponse
from ray import serve
from ray.serve.config import RequestRouterConfig


BACKENDS = {
    "gpu0": "http://127.0.0.1:30000",
    "gpu1": "http://127.0.0.1:30001",
    "gpu2": "http://127.0.0.1:30002",
    "gpu3": "http://127.0.0.1:30003",
}
ROUTING_HEADERS = (
    "X-Session-Id",
    "X-Workload-Request-ID",
    "X-Prefix-Family",
)


def _router_config(router: str) -> RequestRouterConfig | None:
    if router == "p2c":
        return None  # Ray Serve's default power-of-two-choices router.
    if router == "affinity_load_aware":
        return RequestRouterConfig(
            request_router_class=(
                "custom_request_router:AffinityLoadAwareRouter"
            ),
            request_router_kwargs={"imbalance_threshold": 2},
        )
    if router == "consistent_hash":
        os.environ["RAY_SERVE_SESSION_ID_HEADER_KEY"] = "x-session-id"
        return RequestRouterConfig(
            request_router_class=(
                "ray.serve.experimental.consistent_hash_router:ConsistentHashRouter"
            ),
            request_router_kwargs={"num_fallback_replicas": 0},
        )
    raise ValueError(f"Unsupported router: {router}")


fastapi_app = FastAPI()


@serve.deployment(
    name="SGLangProxy",
    num_replicas=4,
    max_replicas_per_node=1,
    ray_actor_options={"num_cpus": 1},
)
@serve.ingress(fastapi_app)
class SGLangProxy:
    def __init__(self) -> None:
        context = serve.get_replica_context()
        self.replica_id = str(context.replica_id)
        self.node_id = str(ray.get_runtime_context().get_node_id())

        node = next(
            (
                item
                for item in ray.nodes()
                if item.get("Alive") and str(item.get("NodeID")) == self.node_id
            ),
            None,
        )
        if node is None:
            raise RuntimeError(f"Ray node {self.node_id} is not in the live node list")

        resources = node.get("Resources", {})
        labels = [name for name in BACKENDS if resources.get(name, 0) >= 1]
        if len(labels) != 1:
            raise RuntimeError(
                f"Ray node {self.node_id} must have exactly one gpu0-gpu3 label; "
                f"found {labels}"
            )
        self.backend_name = labels[0]
        self.backend_url = BACKENDS[self.backend_name]
        self._client: aiohttp.ClientSession | None = None
        self._client_lock = asyncio.Lock()

        print(
            "TARGET3_REPLICA_READY "
            f"replica={self.replica_id} node={self.node_id} "
            f"backend={self.backend_name} url={self.backend_url}",
            flush=True,
        )

    async def _get_client(self) -> aiohttp.ClientSession:
        if self._client is None or self._client.closed:
            async with self._client_lock:
                if self._client is None or self._client.closed:
                    self._client = aiohttp.ClientSession(
                        timeout=aiohttp.ClientTimeout(total=300),
                        connector=aiohttp.TCPConnector(limit=0, keepalive_timeout=90),
                    )
        return self._client

    @fastapi_app.get("/debug/identity")
    async def identity(self) -> dict[str, str]:
        from ray.serve.context import _serve_request_context

        request_context = _serve_request_context.get()
        return {
            "replica_id": self.replica_id,
            "ray_node_id": self.node_id,
            "backend": self.backend_name,
            "session_id": request_context.session_id,
        }

    @fastapi_app.post("/generate")
    async def generate(self, request: Request) -> StreamingResponse:
        body = await request.body()
        forwarded_headers = {
            "Content-Type": request.headers.get("content-type", "application/json")
        }
        for header in ROUTING_HEADERS:
            value = request.headers.get(header)
            if value is not None:
                forwarded_headers[header] = value

        client = await self._get_client()
        upstream = await client.post(
            f"{self.backend_url}/generate",
            data=body,
            headers=forwarded_headers,
        )

        async def stream() -> AsyncIterator[bytes]:
            try:
                async for chunk in upstream.content.iter_any():
                    yield chunk
            finally:
                upstream.release()

        response_headers = {
            "X-Ray-Replica-ID": self.replica_id,
            "X-Ray-Node-ID": self.node_id,
            "X-SGLang-Backend": self.backend_name,
        }
        upstream_content_type = upstream.headers.get("Content-Type")
        if upstream_content_type:
            response_headers["Content-Type"] = upstream_content_type

        return StreamingResponse(
            stream(),
            status_code=upstream.status,
            headers=response_headers,
        )


def main() -> None:
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--router", choices=("p2c", "consistent_hash", "affinity_load_aware"), default="p2c")
    parser.add_argument("--max-ongoing-requests", type=int, default=5)
    args = parser.parse_args()

    ray.init(address="172.17.0.7:6379")
    serve.start(
        proxy_location="HeadOnly",
        http_options={"host": "127.0.0.1", "port": 8000},
    )
    deployment_options = {"max_ongoing_requests": args.max_ongoing_requests}
    router_config = _router_config(args.router)
    if router_config is not None:
        deployment_options["request_router_config"] = router_config
    deployment = SGLangProxy.options(**deployment_options)
    serve.run(deployment.bind(), name="target3", route_prefix="/")
    print(
        f"Ray Serve ready at http://127.0.0.1:8000 "
        f"(router={args.router}, max_ongoing_requests={args.max_ongoing_requests})",
        flush=True,
    )
    import signal
    signal.pause()


if __name__ == "__main__":
    main()
