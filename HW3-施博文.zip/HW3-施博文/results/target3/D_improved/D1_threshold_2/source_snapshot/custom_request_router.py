import hashlib
from typing import List, Optional

from ray.serve.request_router import PendingRequest, RequestRouter, RunningReplica


class AffinityLoadAwareRouter(RequestRouter):
    """Prefer a stable replica for each session unless it is overloaded."""

    def initialize_state(
        self,
        imbalance_threshold: int = 2,
        **kwargs,
    ) -> None:
        self.imbalance_threshold = int(imbalance_threshold)
        if self.imbalance_threshold < 0:
            raise ValueError("imbalance_threshold must be non-negative")

    async def choose_replicas(
        self,
        candidate_replicas: List[RunningReplica],
        pending_request: Optional[PendingRequest] = None,
    ) -> List[List[RunningReplica]]:
        if not candidate_replicas:
            return []

        # Filter replicas that Ray Serve currently considers full.
        available = self.select_available_replicas(
            candidates=candidate_replicas
        )
        if not available:
            return []

        # Keep replica ordering stable so a session hashes to the same replica.
        ordered = sorted(candidate_replicas, key=lambda r: str(r.replica_id))

        session_id = ""
        if pending_request is not None:
            session_id = pending_request.metadata.session_id or ""
            if not session_id:
                session_id = pending_request.metadata.request_id or ""

        # Fall back to a stable ordering-based key if metadata has no ID.
        if not session_id:
            session_id = "default-session"

        digest = hashlib.sha256(session_id.encode("utf-8")).digest()
        preferred_index = int.from_bytes(digest[:8], "big") % len(ordered)
        preferred = ordered[preferred_index]

        # Ray Serve maintains this queue-length cache as requests are routed.
        def queue_length(replica: RunningReplica) -> int:
            value = self.replica_queue_len_cache.get(replica.replica_id)
            return 0 if value is None else value

        least_loaded = min(available, key=queue_length)
        preferred_is_available = any(
            replica.replica_id == preferred.replica_id
            for replica in available
        )

        if preferred_is_available:
            # Keep affinity unless the preferred replica is at least 2
            # requests busier than the least-loaded available replica.
            if (
                queue_length(preferred) - queue_length(least_loaded)
                < self.imbalance_threshold
            ):
                primary = preferred
            else:
                primary = least_loaded
        else:
            primary = least_loaded

        # Each inner list is one preference rank; later ranks are fallbacks.
        fallback_order = sorted(
            (
                replica
                for replica in available
                if replica.replica_id != primary.replica_id
            ),
            key=queue_length,
        )
        return [[primary]] + [[replica] for replica in fallback_order]
