# D 组版本归档

- `D1_threshold_2/`：D1，离散队列阈值 2。
- `D2_threshold_1/`：D2，离散队列阈值 1。
- `D3_ratio_0.10/`：D3，比例负载阈值 0.10；这是最终比例方案。

每个目录保留该轮 `config.json`、`warmups.csv`、`requests.csv`、`summary.json`，并有配套 `source_snapshot/`。D1/D2 的快照使用运行时文件名 `serve_app.py` 与 `custom_request_router.py`，便于复核；完整原始文件名的备份也保留在 `src/target3-routing-policies/`。
