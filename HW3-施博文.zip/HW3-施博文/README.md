# HW3 施博文

本目录提交本次第三次挑战的 Target 3：四后端 Ray Serve 路由策略比较与改进。按要求，本包不包含 Target 1。

## 运行环境

| 项目 | 版本/配置 |
|---|---|
| GPU | 4 × NVIDIA GeForce RTX 4080 SUPER，32 GB/卡，同一台服务器 |
| NVIDIA Driver / CUDA | 595.71.05 / 13.2 |
| Python | 3.12.3 |
| Ray Serve | 2.59.0 |
| SGLang | 0.5.20 |
| PyTorch | 2.13.0 |
| 模型 | Qwen/Qwen3-0.6B |

实验实例将 Ray Serve 与 SGLang 放在独立 Python 环境中。先准备与 GPU 驱动兼容的 Python 3.12.3 环境，再分别安装回放器和服务端依赖：

```bash
# 回放器依赖
python -m pip install -r src/target3/requirements.txt

# Ray Serve 环境
python -m pip install "ray[serve]==2.59.0"

# SGLang 环境：先确保 PyTorch wheel 与当前 CUDA/驱动兼容
python -m pip install "torch==2.13.0" "sglang==0.5.20"
```

本次 AutoDL 实例使用的版本见上表；模型权重需预先下载到服务器，模型文件不包含在提交包内。

## 固定负载与安装

正式实验使用 `src/target3/mooncake_prefix_workload_v2_seed2026.jsonl`，不得修改请求、到达时间或顺序。SHA-256 为 `f154ba954e28ca9612257edf5deb0d5dfc6bf27fd0115a701e1f49e52df75b03`。校验结果为 64 个前缀族、64 条预热请求和 2048 条测量请求。

```bash
cd src/target3
python -m pip install -r requirements.txt
python validate_workload.py mooncake_prefix_workload_v2_seed2026.jsonl
```

## 启动服务

先在四个终端分别启动 SGLang 后端（模型目录需已下载，示例为本次 AutoDL 路径）：

```bash
CUDA_VISIBLE_DEVICES=0 /root/autodl-tmp/envs/sglang/bin/sglang serve --model-path /root/autodl-tmp/models/Qwen3-0.6B --host 127.0.0.1 --port 30000 --tp-size 1 --served-model-name Qwen/Qwen3-0.6B
CUDA_VISIBLE_DEVICES=1 /root/autodl-tmp/envs/sglang/bin/sglang serve --model-path /root/autodl-tmp/models/Qwen3-0.6B --host 127.0.0.1 --port 30001 --tp-size 1 --served-model-name Qwen/Qwen3-0.6B
CUDA_VISIBLE_DEVICES=2 /root/autodl-tmp/envs/sglang/bin/sglang serve --model-path /root/autodl-tmp/models/Qwen3-0.6B --host 127.0.0.1 --port 30002 --tp-size 1 --served-model-name Qwen/Qwen3-0.6B
CUDA_VISIBLE_DEVICES=3 /root/autodl-tmp/envs/sglang/bin/sglang serve --model-path /root/autodl-tmp/models/Qwen3-0.6B --host 127.0.0.1 --port 30003 --tp-size 1 --served-model-name Qwen/Qwen3-0.6B
```

确认四个 `/flush_cache` 请求成功后，启动 Ray head 和四个逻辑 worker：

```bash
bash start_ray_cluster.sh
```

在 `src/target3` 目录用 Ray 环境部署 Serve。每轮要按本轮配置启动，并确保部署参数与回放命令里的记录一致：

```bash
/root/autodl-tmp/envs/rayserve/bin/python serve_app.py --router p2c --max-ongoing-requests 10
```

`--router` 可设为 `p2c`、`consistent_hash` 或 `affinity_load_aware`。C 使用 `consistent_hash` 和并发上限 10；D 使用 `affinity_load_aware` 和并发上限 10，比例阈值 0.10 在 `serve_app.py` 中配置。`start_ray_cluster.sh` 会在 Ray 启动前设置 `RAY_SERVE_SESSION_ID_HEADER_KEY=x-session-id`。

## 回放命令

以下为 B1 的回放示例。每轮部署对应 Serve 配置、清空四个后端缓存后，再启动流量回放：

```bash
/root/autodl-tmp/envs/rayserve/bin/python run_workload.py \
  --policy serve \
  --run-name B1_p2c_10 \
  --router-name p2c \
  --max-ongoing-requests 10 \
  --base-url http://127.0.0.1:8000 \
  --workload mooncake_prefix_workload_v2_seed2026.jsonl \
  --max-in-flight 2048 \
  --output-dir ../../results/target3/B_candidates/B1_p2c_10
```

A、B2、C、D 的 router、并发上限和输出目录分别见 `results/target3` 下的 `config.json`。已有结果目录不会被回放器覆盖；重跑时请使用新目录或明确传入 `--overwrite`。

## 脚本和结果

| 路径/脚本 | 用途 |
|---|---|
| `validate_workload.py` | 校验固定负载摘要、数量和阶段 |
| `run_workload.py` | HTTP/SSE 预热、回放并记录逐请求 CSV 与汇总 JSON |
| `compare_runs.py` | 校验并汇总不同配置的实验结果 |
| `start_ray_cluster.sh` | 启动 1 个 head 与 4 个逻辑 worker |
| `serve_app.py` | 启动四副本 Ray Serve 代理并配置 A/B/C/D 路由 |
| `custom_request_router.py` | D3 比例阈值亲和负载感知路由 |

`results/target3/target3_main_table.csv` 是报告主表的数据来源；A、B1、B2、C、D1、D2、D3 的原始 `config.json`、`warmups.csv`、`requests.csv`、`summary.json` 均保存在对应结果目录。D1/D2/D3 的实现快照和过程记录也一并保留。`report.pdf` 中的结果表与这些 JSON 汇总对应。

本次每个配置运行一轮；报告按单轮观察陈述结果。未提交模型权重、Python 环境、安装包或缓存。
