#!/usr/bin/env bash
set -euo pipefail

ulimit -n 65535
export RAY_AUTH_MODE=disabled
export RAY_SERVE_SESSION_ID_HEADER_KEY=x-session-id
RAY=/root/autodl-tmp/envs/rayserve/bin/ray
RAY_TMP=/root/autodl-tmp/ray
mkdir -p "$RAY_TMP"

"$RAY" stop --force || true
sleep 2

"$RAY" start --head \
  --port=6379 \
  --num-cpus=0 \
  --num-gpus=0 \
  --dashboard-host=127.0.0.1 \
  --temp-dir="$RAY_TMP" \
  --min-worker-port=10002 \
  --max-worker-port=10999 \
  --disable-usage-stats

CUDA_VISIBLE_DEVICES=0 "$RAY" start \
  --address=172.17.0.7:6379 --num-cpus=12 --num-gpus=1 \
  --resources='{"gpu0": 1}' --temp-dir="$RAY_TMP" \
  --min-worker-port=11000 --max-worker-port=11999 --disable-usage-stats

CUDA_VISIBLE_DEVICES=1 "$RAY" start \
  --address=172.17.0.7:6379 --num-cpus=12 --num-gpus=1 \
  --resources='{"gpu1": 1}' --temp-dir="$RAY_TMP" \
  --min-worker-port=12000 --max-worker-port=12999 --disable-usage-stats

CUDA_VISIBLE_DEVICES=2 "$RAY" start \
  --address=172.17.0.7:6379 --num-cpus=12 --num-gpus=1 \
  --resources='{"gpu2": 1}' --temp-dir="$RAY_TMP" \
  --min-worker-port=13000 --max-worker-port=13999 --disable-usage-stats

CUDA_VISIBLE_DEVICES=3 "$RAY" start \
  --address=172.17.0.7:6379 --num-cpus=12 --num-gpus=1 \
  --resources='{"gpu3": 1}' --temp-dir="$RAY_TMP" \
  --min-worker-port=14000 --max-worker-port=14999 --disable-usage-stats
